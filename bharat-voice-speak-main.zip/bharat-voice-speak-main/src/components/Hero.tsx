import { Button } from "@/components/ui/button";
import { Mic, Globe, Languages, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroImage from "@/assets/hero-image.jpg";

const Hero = () => {
  const navigate = useNavigate();

  const handleTryDemo = () => {
    navigate("/languages");
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 gradient-hero" />
      
      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 text-center">
        <div className="animate-bounce-in">
          <div className="flex justify-center mb-6">
            <div className="p-4 rounded-full gradient-primary shadow-glow">
              <Mic className="w-12 h-12 text-primary-foreground" />
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            VoiceBridge India
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Real-time voice translation across all 22 official Indian languages. 
            Break language barriers and connect with everyone.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              variant="hero" 
              size="xl" 
              onClick={handleTryDemo}
              className="group"
            >
              <Languages className="w-6 h-6 mr-2 group-hover:scale-110 animate-smooth" />
              Try Demo
            </Button>
            <Button variant="outline" size="xl">
              <Globe className="w-6 h-6 mr-2" />
              Learn More
            </Button>
          </div>
          
          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center p-6 rounded-lg gradient-hero animate-smooth hover:shadow-soft">
              <div className="p-3 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                <Zap className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Real-time Translation</h3>
              <p className="text-muted-foreground">Instant voice translation with high accuracy</p>
            </div>
            
            <div className="text-center p-6 rounded-lg gradient-hero animate-smooth hover:shadow-soft">
              <div className="p-3 rounded-full bg-accent/10 w-fit mx-auto mb-4">
                <Languages className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-lg font-semibold mb-2">22 Indian Languages</h3>
              <p className="text-muted-foreground">Support for all official Indian languages</p>
            </div>
            
            <div className="text-center p-6 rounded-lg gradient-hero animate-smooth hover:shadow-soft">
              <div className="p-3 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                <Globe className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Cultural Context</h3>
              <p className="text-muted-foreground">Preserves cultural nuances in translation</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;