import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

// Language mapping based on your Python code - matches Google Translate codes exactly
const indianLanguages = [
  { code: "as", name: "Assamese", native: "অসমীয়া" },
  { code: "bn", name: "Bengali", native: "বাংলা" },
  { code: "brx", name: "Bodo", native: "बर'" },
  { code: "doi", name: "Dogri", native: "डोगरी" },
  { code: "gu", name: "Gujarati", native: "ગુજરાતી" },
  { code: "hi", name: "Hindi", native: "हिन्दी" },
  { code: "kn", name: "Kannada", native: "ಕನ್ನಡ" },
  { code: "ks", name: "Kashmiri", native: "कॉशुर" },
  { code: "kok", name: "Konkani", native: "कोंकणी" },
  { code: "mai", name: "Maithili", native: "मैथिली" },
  { code: "ml", name: "Malayalam", native: "മലയാളം" },
  { code: "mni", name: "Manipuri", native: "ꯃꯤꯇꯩ ꯂꯣꯟ" },
  { code: "mr", name: "Marathi", native: "मराठी" },
  { code: "ne", name: "Nepali", native: "नेपाली" },
  { code: "or", name: "Odia", native: "ଓଡ଼ିଆ" },
  { code: "pa", name: "Punjabi", native: "ਪੰਜਾਬੀ" },
  { code: "sa", name: "Sanskrit", native: "संस्कृत" },
  { code: "sat", name: "Santali", native: "ᱥᱟᱱᱛᱟᱲᱤ" },
  { code: "sd", name: "Sindhi", native: "سنڌي" },
  { code: "ta", name: "Tamil", native: "তামিল" },
  { code: "te", name: "Telugu", native: "తেলুগু" },
  { code: "ur", name: "Urdu", native: "اردو" }
];

const LanguageSelector = () => {
  const navigate = useNavigate();
  const [fromLanguage, setFromLanguage] = useState<string>("");
  const [toLanguage, setToLanguage] = useState<string>("");

  const handleContinue = () => {
    if (fromLanguage && toLanguage && fromLanguage !== toLanguage) {
      navigate(`/translator?from=${fromLanguage}&to=${toLanguage}`);
    }
  };

  const handleBack = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <Button 
            variant="ghost" 
            onClick={handleBack}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
          
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Select Languages
          </h1>
          <p className="text-xl text-muted-foreground">
            Choose the languages you want to translate between
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* From Language */}
          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-6 text-center text-primary">
              From Language
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
              {indianLanguages.map((lang) => (
                <button
                  key={`from-${lang.code}`}
                  onClick={() => setFromLanguage(lang.code)}
                  className={`p-3 rounded-lg border text-left animate-smooth hover:shadow-soft ${
                    fromLanguage === lang.code
                      ? "border-primary gradient-primary text-primary-foreground"
                      : "border-border hover:border-primary/50"
                  }`}
                >
                  <div className="font-medium">{lang.name}</div>
                  <div className="text-sm opacity-80">{lang.native}</div>
                </button>
              ))}
            </div>
          </Card>

          {/* To Language */}
          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-6 text-center text-accent">
              To Language
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
              {indianLanguages.map((lang) => (
                <button
                  key={`to-${lang.code}`}
                  onClick={() => setToLanguage(lang.code)}
                  disabled={lang.code === fromLanguage}
                  className={`p-3 rounded-lg border text-left animate-smooth hover:shadow-soft disabled:opacity-50 disabled:cursor-not-allowed ${
                    toLanguage === lang.code
                      ? "border-accent gradient-accent text-accent-foreground"
                      : "border-border hover:border-accent/50"
                  }`}
                >
                  <div className="font-medium">{lang.name}</div>
                  <div className="text-sm opacity-80">{lang.native}</div>
                </button>
              ))}
            </div>
          </Card>
        </div>

        {/* Continue Button */}
        <div className="text-center">
          <Button
            variant="hero"
            size="xl"
            onClick={handleContinue}
            disabled={!fromLanguage || !toLanguage || fromLanguage === toLanguage}
            className="group"
          >
            Continue to Translator
            <ArrowRight className="w-6 h-6 ml-2 group-hover:translate-x-1 animate-smooth" />
          </Button>
          
          {fromLanguage && toLanguage && fromLanguage === toLanguage && (
            <p className="text-destructive mt-4">
              Please select different languages for translation
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default LanguageSelector;