import { useState, useEffect, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Mic, MicOff, Volume2, ArrowLeft, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/hooks/useTranslation";

// Extend the Window interface for speech recognition
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

const indianLanguages: Record<string, { name: string; native: string }> = {
  hi: { name: "Hindi", native: "हिन्दी" },
  bn: { name: "Bengali", native: "বাংলা" },
  te: { name: "Telugu", native: "తెలుగు" },
  mr: { name: "Marathi", native: "मराठी" },
  ta: { name: "Tamil", native: "தமிழ்" },
  ur: { name: "Urdu", native: "اردو" },
  gu: { name: "Gujarati", native: "ગુજરાતી" },
  kn: { name: "Kannada", native: "ಕನ್ನಡ" },
  ml: { name: "Malayalam", native: "മലയാളം" },
  or: { name: "Odia", native: "ଓଡ଼ିଆ" },
  pa: { name: "Punjabi", native: "ਪੰਜਾਬੀ" },
  as: { name: "Assamese", native: "অসমীয়া" }
};

const VoiceTranslator = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const fromLang = searchParams.get("from") || "hi";
  const toLang = searchParams.get("to") || "en";
  
  const [isRecording, setIsRecording] = useState(false);
  const [originalText, setOriginalText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  
  const { translateText, isTranslating } = useTranslation();
  const recognitionRef = useRef<any>(null);

  // Language mapping for speech recognition
  const speechLangMap: Record<string, string> = {
    hi: "hi-IN",
    bn: "bn-IN", 
    te: "te-IN",
    mr: "mr-IN",
    ta: "ta-IN",
    ur: "ur-PK",
    gu: "gu-IN",
    kn: "kn-IN",
    ml: "ml-IN",
    or: "or-IN",
    pa: "pa-IN",
    as: "as-IN",
    en: "en-US"
  };

  // Translation is now handled by the backend service
  useEffect(() => {
    toast({
      title: "IndicTrans2 AI Ready",
      description: "Backend translation service powered by IndicTrans2",
    });
  }, []);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      const recognition = recognitionRef.current;
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      
      recognition.onresult = async (event) => {
        const transcript = event.results[0][0].transcript;
        setOriginalText(transcript);
        setIsRecording(false);
        
        // Start translation using backend service
        const result = await translateText(transcript, fromLang, toLang);
        setTranslatedText(result);
      };
      
      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsRecording(false);
        toast({
          title: "Speech Recognition Error",
          description: "Please try again or check your microphone",
          variant: "destructive",
        });
      };
      
      recognition.onend = () => {
        setIsRecording(false);
      };
    }
  }, []);

  const handleManualTranslate = async () => {
    if (!originalText.trim()) return;
    
    const result = await translateText(originalText, fromLang, toLang);
    setTranslatedText(result);
  };

  const handleToggleRecording = async () => {
    if (!recognitionRef.current) {
      toast({
        title: "Speech recognition not supported",
        description: "Your browser doesn't support speech recognition",
        variant: "destructive",
      });
      return;
    }

    if (!isRecording) {
      try {
        // Request microphone permission
        await navigator.mediaDevices.getUserMedia({ audio: true });
        
        const recognition = recognitionRef.current;
        recognition.lang = speechLangMap[fromLang] || "en-US";
        
        setIsRecording(true);
        recognition.start();
        
        toast({
          title: "Recording started",
          description: `Listening in ${indianLanguages[fromLang]?.name}...`,
        });
      } catch (error) {
        toast({
          title: "Microphone access denied",
          description: "Please allow microphone access to use voice translation",
          variant: "destructive",
        });
      }
    } else {
      recognitionRef.current?.stop();
      setIsRecording(false);
    }
  };

  const handlePlayAudio = () => {
    if (!translatedText) return;
    
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(translatedText);
      utterance.lang = speechLangMap[toLang] || "en-US";
      utterance.rate = 0.9;
      speechSynthesis.speak(utterance);
      
      toast({
        title: "Playing translation",
        description: "AI-powered text-to-speech",
      });
    } else {
      toast({
        title: "Text-to-speech not supported",
        description: "Your browser doesn't support audio playback",
        variant: "destructive",
      });
    }
  };

  const handleClear = () => {
    setOriginalText("");
    setTranslatedText("");
  };

  const handleBack = () => {
    navigate("/languages");
  };

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Button 
            variant="ghost" 
            onClick={handleBack}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Language Selection
          </Button>
          
          <h1 className="text-3xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Voice Translator
          </h1>
          
          <div className="flex items-center justify-center gap-4 text-lg">
            <span className="font-medium text-primary">
              {indianLanguages[fromLang]?.name || fromLang} ({indianLanguages[fromLang]?.native})
            </span>
            <ArrowLeft className="w-6 h-6 rotate-180 text-muted-foreground" />
            <span className="font-medium text-accent">
              {indianLanguages[toLang]?.name || toLang} ({indianLanguages[toLang]?.native})
            </span>
          </div>
        </div>


        {/* Recording Interface */}
        <div className="text-center mb-8">
          <div className="relative inline-block">
            <Button
              variant={isRecording ? "destructive" : "hero"}
              size="icon"
              onClick={handleToggleRecording}
              disabled={isTranslating}
              className={`w-24 h-24 rounded-full ${isRecording ? 'animate-pulse' : ''}`}
            >
              {isRecording ? (
                <MicOff className="w-12 h-12" />
              ) : (
                <Mic className="w-12 h-12" />
              )}
            </Button>
            
            {isRecording && (
              <div className="absolute inset-0 rounded-full border-4 border-destructive animate-ping" />
            )}
          </div>
          
          <p className="mt-4 text-lg text-muted-foreground">
            {isTranslating 
              ? "IndicTrans2 is translating..." 
              : isRecording 
                ? `Listening in ${indianLanguages[fromLang]?.name}... Tap to stop` 
                : "Tap to start IndicTrans2 AI translation"
            }
          </p>
        </div>

        {/* Translation Results */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Original Text */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-primary">
                Original ({indianLanguages[fromLang]?.name})
              </h3>
            </div>
            
            <div className="min-h-32 p-4 bg-muted rounded-lg">
              {originalText ? (
                <p className="text-lg">{originalText}</p>
              ) : (
                <p className="text-muted-foreground italic">
                  Your speech will appear here...
                </p>
              )}
            </div>
          </Card>

          {/* Translated Text */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-accent">
                Translation ({indianLanguages[toLang]?.name || toLang})
              </h3>
              
              {translatedText && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePlayAudio}
                >
                  <Volume2 className="w-4 h-4 mr-2" />
                  Play
                </Button>
              )}
            </div>
            
            <div className="min-h-32 p-4 bg-muted rounded-lg relative">
              {isTranslating ? (
                <div className="flex items-center justify-center h-full">
                  <RefreshCw className="w-6 h-6 animate-spin text-primary mr-2" />
                  <span className="text-muted-foreground">Translating...</span>
                </div>
              ) : translatedText ? (
                <p className="text-lg">{translatedText}</p>
              ) : (
                <p className="text-muted-foreground italic">
                  Translation will appear here...
                </p>
              )}
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center gap-4">
          <Button
            variant="outline"
            onClick={handleClear}
            disabled={!originalText && !translatedText}
          >
            Clear All
          </Button>
          
          <Button
            variant="accent"
            onClick={() => {
              setOriginalText("");
              setTranslatedText("");
              handleToggleRecording();
            }}
          >
            New Translation
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VoiceTranslator;