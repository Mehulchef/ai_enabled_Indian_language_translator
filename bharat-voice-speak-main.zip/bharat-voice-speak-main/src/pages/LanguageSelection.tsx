import LanguageSelector from "@/components/LanguageSelector";

const LanguageSelection = () => {
  return <LanguageSelector />;
};

export default LanguageSelection;