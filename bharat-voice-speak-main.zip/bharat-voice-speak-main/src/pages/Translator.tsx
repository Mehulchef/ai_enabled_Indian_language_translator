import VoiceTranslator from "@/components/VoiceTranslator";

const Translator = () => {
  return <VoiceTranslator />;
};

export default Translator;