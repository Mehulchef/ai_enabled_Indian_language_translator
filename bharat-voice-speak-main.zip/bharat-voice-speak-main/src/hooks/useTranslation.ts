import { useState } from 'react'
import { useToast } from '@/hooks/use-toast'

interface TranslationResult {
  translatedText: string
  originalText: string
  fromLang: string
  toLang: string
}

export const useTranslation = () => {
  const [isTranslating, setIsTranslating] = useState(false)
  const { toast } = useToast()

  const translateText = async (
    text: string,
    fromLang: string,
    toLang: string
  ): Promise<string> => {
    if (!text.trim()) {
      return ''
    }

    setIsTranslating(true)

    try {
      // FastAPI backend URL - update this to match your main.py server
      const FASTAPI_URL = 'http://localhost:8000'; // Your FastAPI server URL
      
      const response = await fetch(`${FASTAPI_URL}/api/translate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: text.trim(),
          source_lang: fromLang,
          target_lang: toLang
        })
      })

      if (!response.ok) {
        throw new Error(`Translation failed: ${response.statusText}`)
      }

      const result = await response.json()
      
      toast({
        title: "Translation complete",
        description: "Powered by Google Translate via FastAPI",
      })

      // Expecting Flask API to return: { translated_text: "...", original_text: "..." }
      return result.translated_text || result.translatedText

    } catch (error) {
      console.error('Translation error:', error)
      
      toast({
        title: "Translation failed",
        description: "Please check if FastAPI backend is running on port 8000",
        variant: "destructive",
      })

      // Return original text as fallback
      return `[Translation of: ${text}]`
    } finally {
      setIsTranslating(false)
    }
  }

  return {
    translateText,
    isTranslating
  }
}